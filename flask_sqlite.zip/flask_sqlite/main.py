from flask import *
import sqlite3

app = Flask(__name__)


@app.route("/")
def start():
    return render_template("login.html");


@app.route("/register")
def register():
    return render_template("register.html");

@app.route("/display")
def display():
    return render_template("display.html");

@app.route("/indexmarks")
def indexmarks():
    return render_template("indexmarks.html");

@app.route("/index")
def index():
    return render_template("index.html");

@app.route("/add")
def add():
    return render_template("add.html")

@app.route("/addmarks")
def addmarks():
    return render_template("addmarks.html")


@app.route("/logout")
def logout():
    return render_template("logout.html")


@app.route("/savedetails", methods=["POST", "GET"])
def saveDetails():
    msg = "msg"
    if request.method == "POST":
        try:
            name = request.form["name"]
            email = request.form["email"]
            address = request.form["address"]
            with sqlite3.connect("student2.db") as con:
                cur = con.cursor()
                cur.execute("INSERT into Student (name, email, address) values (?,?,?)", (name, email, address))
                con.commit()
                msg = "Student successfully Added"
        except:
            con.rollback()
            msg = "We can not add the Student to the list"
        finally:
            return render_template("success.html", msg=msg)
            con.close()

@app.route("/savemarks", methods=["POST", "GET"])
def saveMarks():
    msg = "msg"
    if request.method == "POST":
        try:
            name = request.form["name"]
            Sub1 = request.form["Sub1"]
            Sub2 = request.form["Sub2"]
            Sub3 = request.form["Sub3"]
            Total = request.form["Total"]
            with sqlite3.connect("studentmarks.db") as con:
                cur = con.cursor()
                cur.execute("INSERT into Marks1 (name, Sub1, Sub2, Sub3, Total) values (?,?,?,?,?)", (name, Sub1, Sub2, Sub3, Total))
                con.commit()
                msg = "Student Marks successfully Added"
        except:
            con.rollback()
            msg = "We can not add the Student to the list"
        finally:
            return render_template("successm1.html", msg=msg)
            con.close()


@app.route("/saveatt", methods=["POST", "GET"])
def saveAtt():
    msg = "msg"
    if request.method == "POST":
        try:
            name = request.form["name"]
            att1 = request.form["att1"]
            att2 = request.form["att2"]
            att3 = request.form["att3"]
            with sqlite3.connect("att.db") as con:
                cur = con.cursor()
                cur.execute("INSERT into Att (name, att1, att2, att3) values (?,?,?,?)", (name, att1, att2, att3))
                con.commit()
                msg = "Student Attendance successfully Added"
        except:
            con.rollback()
            msg = "We can not add Attendance to the list"
        finally:
            return render_template("successa1.html", msg=msg)
            con.close()


@app.route("/view")
def view():
    con = sqlite3.connect("student2.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from Student")
    rows = cur.fetchall()
    return render_template("view.html", rows=rows)

@app.route("/viewmarks")
def viewmarks():
    con = sqlite3.connect("studentmarks.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from Marks1")
    rows = cur.fetchall()
    return render_template("viewmarks.html", rows=rows)

@app.route("/viewatt")
def viewatt():
    con = sqlite3.connect("att.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    print("Hi")
    cur.execute("select * from Att")
    print('ki')
    rows = cur.fetchall()
    return render_template("viewatt.html", rows=rows)



@app.route("/delete")
def delete():
    return render_template("delete.html")

@app.route("/indexatt")
def indexatt():
    return render_template("indexatt.html")

@app.route("/deleteatt")
def deleteatt():
    return render_template("deleteatt.html")


@app.route("/pie")
def pie():
    return render_template("pie.html")

@app.route("/timetablr")
def timetablr():
    return render_template("timetablr.html")

@app.route("/pieatt")
def pieatt():
    return render_template("pieatt.html")

@app.route("/delete-m")
def deletem():
    return render_template("delete-m.html")

@app.route("/search")
def search():
    return render_template("search.html")

@app.route("/addatt")
def addatt():
    return render_template("addatt.html")


@app.route("/deleterecord", methods=["POST"])
def deleterecord():
    id = request.form["id"]
    with sqlite3.connect("student2.db") as con:
        try:
            cur = con.cursor()
            cur.execute("delete from Student where id = ?", id)
            msg = "Record successfully deleted"
        except:
            msg = "Can't be deleted"
        finally:
            return render_template("delete_record.html", msg=msg)

@app.route("/deletemarks", methods=["POST"])
def deletemarks():
    id = request.form["id"]
    with sqlite3.connect("studentmarks.db") as con:
        try:
            cur = con.cursor()
            cur.execute("delete from Marks1 where id = ?", id)
            msg = "Record successfully deleted"
        except:
            msg = "Can't be deleted"
        finally:
            return render_template("delete_marks.html", msg=msg)

@app.route("/deletea", methods=["POST"])
def deletea():
    id = request.form["id"]
    with sqlite3.connect("att.db") as con:
        try:
            cur = con.cursor()
            cur.execute("delete from Att where id = ?", id)
            msg = "Record successfully deleted"
        except:
            msg = "Can't be deleted"
        finally:
            return render_template("delete_att.html", msg=msg)



@app.route("/searchstudent", methods=["POST", "GET"])
def searchstudent():
    msg = "msg"
    if request.method == "POST":
        try:
            id = request.form["id"]
            with sqlite3.connect("student2.db") as con:
                cur = con.cursor()
                print('Step 1')
                cur.execute("viewstudent.html")
                print('Step 2')
                con.commit()
                msg = "Student Details"
        except:
            con.rollback()
            msg = "We can not show the Details."
        finally:
            return render_template("searchstudent.html", msg=msg)
            con.close()

@app.route("/validatepassword", methods=["POST", "GET"])
def validatepassword():
    msg = "msg"
    if request.method == "POST":
        try:
            name = request.form["username"]
            pwd = request.form["password"]
            with sqlite3.connect("student2.db") as con:
                cur = con.cursor()
                cur.execute("Select username,password from users where username = ? and password = ? ",(name, pwd))
                result = cur.fetchone()
                if result:
                    if (result[0] == name and result[1] == pwd):
                        return render_template("display.html")
                else:
                    msg = "Invalid Username or Password."
                    print(msg)
                    return render_template("loginfail.html", msg=msg)

        except:
            msg = "Sorry! Try Again!!"

        finally:
            con.close()



@app.route("/createuser", methods=["POST", "GET"])
def createuser():
    msg = "msg"
    if request.method == "POST":
        try:
            name = request.form["name"]
            uname = request.form["uname"]
            pwd = request.form["password"]
            with sqlite3.connect("student2.db") as con:
                cur = con.cursor()
                cur.execute("INSERT into users (username, password) values (?,?)", (uname, pwd))
                con.commit()
                msg = "Created Sucessfully"
        except:
            con.rollback()
            msg = "Sorry! Try Again!!"
        finally:
            return render_template("login.html", msg=msg)
            con.close()

if __name__ == "__main__":
    app.run(debug=True)


