import sqlite3

con = sqlite3.connect("studentmarks.db")
print("Database opened successfully")

con.execute("create table Marks1 (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, Sub1 INTEGER, Sub2 INTEGER, Sub3 INTEGER, Total INTEGER)")

print("Table created successfully")

con.close()