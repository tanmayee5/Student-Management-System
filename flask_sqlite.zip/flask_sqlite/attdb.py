import sqlite3

con = sqlite3.connect("att.db")
print("Database opened successfully")

con.execute("create table Att (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, att1 INTEGER, att2 INTEGER, att3 INTEGER)")

print("Table created successfully")

con.close()